package cofrinho;

public class Real extends Moeda {
	
	
	public Real(double valor) {
		super(valor , "R$");
		
	}

	double valorReal;
	
//retorna o valor em real. Não é necessário nenhum tipo de conversão.
	public double converterValor() {
		return getValor();
	}
	

}
