package cofrinho;

public class Moeda {
	
		
	protected double valor;
	protected String moedaPais;
	

	public Moeda(double valor, String moedaPais) {	
		this.valor = valor;
		this.moedaPais = moedaPais;
		
		
	}
	

	public double getValor() {
		return valor;
	}
	
	
	public String getmoedaPais() {
		return moedaPais;
	}



	public double converterValor() {
		return valor;
	}

}
