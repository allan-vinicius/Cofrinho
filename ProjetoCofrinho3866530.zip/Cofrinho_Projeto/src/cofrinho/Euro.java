package cofrinho;

public class Euro extends Moeda {

	public Euro(double valor) {
		super(valor, "EUR$ ");
		
	}
	
	@Override
	public double converterValor() {
		//retorna o valor e converte para o valor em euro
		return getValor() * 5.60;
	}

}
