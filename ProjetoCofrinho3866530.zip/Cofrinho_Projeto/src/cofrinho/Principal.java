package cofrinho;

import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		//Scanner para imprimir as informações na tela	
		Scanner imprimir = new Scanner(System.in);
		
		int selecionar;
		// Criação do objeto para o armazenamento das moedas
		Cofrinho meuCofrinho = new Cofrinho();
		
		// 	o do/While para executar o código enquanto a condição verificada for verdadeira.
		do {
			System.out.println("Página inicial");
			System.out.println("Selecione a opção desejada");
			System.out.println("1 - Adcionar; \n2 - Remover; \n3 - Lista; \n4 - Total em R$; \n0 - Sair");
			
			selecionar=imprimir.nextInt();
			System.out.println();
			
			//Switch/case para avaliar a opção selecionar e verificar se a opção verdadeira está sendo executada 
			switch (selecionar) {
			case 1:
				System.out.println("Selecione a moeda: ");
				System.out.println("1 - Real \n2 - Dolar \n3 - Euro");
				
				int addMoeda = imprimir.nextInt();
				
				System.out.println("Qual o valor: ");
				
				double valor = imprimir.nextDouble();
				System.out.println();
				
				Moeda valorMoeda = null;
				
				//Criar uma instância da classe selecionada (Real, Dolar ou Euro)
				switch (addMoeda) {
				case 1:
					valorMoeda = new Real(valor);
					break;
				case 2 :
					valorMoeda = new Dolar(valor);
					break;
				case 3:
					valorMoeda = new Euro(valor);
					break;
				default:
					System.out.println("Opção inválida");
					System.out.println();
					return;
				
				}
				//Adcionar moeda ao cofrinho
				meuCofrinho.adicionar(valorMoeda);
				break;
			
				//Caso para remover moeda do cofrinho
			case 2:
				System.out.println("Qual o valor a ser removido? ");
				System.out.println();
				double valorRemove = imprimir.nextDouble();
				
				Moeda removerMoeda = null;
				
				for (Moeda moeda1 : meuCofrinho.getlistarMoedas()) {
					if (moeda1.getValor() == valorRemove) {
						removerMoeda = moeda1;
						break;
					}	
				}
				
				if (removerMoeda != null) {
					meuCofrinho.remover(removerMoeda);
					System.out.println("Moeda removida!");
					System.out.println();
				}
				break;
				
				//Lista para verificar as moedas armazenadas no cofrinho
			case 3:
				System.out.println("Meu saldo");
				meuCofrinho.listar();
				System.out.println();
				break;
				
				//Calcular o valor armazenado transformando em Real
			case 4:
				double total = meuCofrinho.totalEmReal();
				System.out.println("Total em real: " + total + "R$");
				System.out.println();
				break;
				
				//Opção para encerrar o programa
			case 0:
				System.out.println("Encerrando!");
			default:
				System.out.println("Opção inválida!");
				System.out.println();
			}
			
			
	} while (selecionar != 0);
		imprimir.close();
	
	}
	
}
	

