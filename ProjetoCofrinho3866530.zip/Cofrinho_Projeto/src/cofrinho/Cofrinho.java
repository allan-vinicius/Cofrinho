package cofrinho;


import java.util.ArrayList;

import java.util.List;


public class Cofrinho {
	private List<Moeda> listaMoedas;
	
	//Criar uma lista vazia
	public Cofrinho() {
		listaMoedas = new ArrayList<>();
	}
	
	//adcionar moeda na lista do cofrinho
	public void adicionar(Moeda m) {
		listaMoedas.add(m);
		
	}
	//remover moeda na lista do cofrinho
	public void remover(Moeda m) {
		listaMoedas.remove(m);
	}
	//Mostrar a lista de moedas do cofrinho
	public List<Moeda> getlistarMoedas() {
	
		return listaMoedas;
	}
	public void listar() {
		for(Moeda m : listaMoedas) 
			System.out.println(m.getValor() + " " + m.getmoedaPais());
	}
	
	//repete as moedas e converte para o valor equivalente em real
	public double totalEmReal() {
		double total = 0;
		for (Moeda m : listaMoedas) {
			total += m.converterValor();
		}
		return total;
		
		
	}


	public void getlistaMoeda() {
		
		
	}


	

}
