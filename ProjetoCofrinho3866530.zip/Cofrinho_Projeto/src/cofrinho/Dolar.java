package cofrinho;

public class Dolar extends Moeda {
	public Dolar(double valor) {
		super(valor, "USD$");
		
	}


	@Override
	public double converterValor() {
		//retorna o valor e converte para o valor em dolar
		return getValor() * 4.86;
	}

}
